import openpyxl

def readsummary(filePath, sheetName):
    workbook = openpyxl.load_workbook(filePath)
    sheet = workbook[sheetName]

    content = (
        "%-------------------------------------------------------------------------------\n"
        "%SECTION TITLE\n"
        "%-------------------------------------------------------------------------------\n"
        "\cvsection{Summary}\n"
        "%-------------------------------------------------------------------------------\n"
        "%CONTENT\n"
        "%-------------------------------------------------------------------------------\n"
        "\begin{cvparagraph}\n"
        "%---------------------------------------------------------\n"
               )

    data = f"{sheet.cell(row=1, column=1).value}\n"
    content = content + data


    end ="\end{cvparagraph}"

    content = content +end

    file = open('resume/summary.tex','w')
    file.write(content)
    file.close()