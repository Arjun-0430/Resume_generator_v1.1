import openpyxl


def readskills(filePath, sheetName):
    workbook = openpyxl.load_workbook(filePath)
    sheet = workbook[sheetName]

    content = (
        "%-------------------------------------------------------------------------------\n"
        "%	CONTENT\n"
        "%-------------------------------------------------------------------------------\n"
        "\\begin{cvskills}\n"
    )

    for i in range(1,8):
         data = (
             "\n%---------------------------------------------------------\n"
             "\cvskill\n"
             "\t"+"{"+f"{sheet.cell(row=i, column=1).value}"+"} %Category\n"
             "\t" + "{" + f"{sheet.cell(row=i, column=2).value}" + "} %Skills\n"
         )
         content = content + data

    end = (
        "%---------------------------------------------------------\n"
        "\end{cvskills}"
    )

    content = content + end

    file = open('resume/skills.tex', 'w')
    file.write(content)
    file.close()