import openpyxl

def readwork(filePath, sheetName):
    workbook = openpyxl.load_workbook(filePath)
    sheet = workbook.active

    content = ("%-------------------------------------------------------------------------------\n"
               "%	SECTION TITLE\n"
               "%-------------------------------------------------------------------------------\n"
               "\cvsection{Work Experience}\n"

               "%-------------------------------------------------------------------------------\n"
               "%	CONTENT\n"
               "%-------------------------------------------------------------------------------\n"
               "\\begin{cventries}\n")
    k = 1
    for i in range(1, 4):
        data = (
                "\n%---------------------------------------------------------\n"
                "\cventry\n"
                "\t" + "{" + f"{sheet.cell(row=k, column=1).value}" + "} %Organization\n"
                "\t" + "{" + f"{sheet.cell(row=k + 1, column=1).value}" + "} %Job\n"
                "\t" + "{" + f"{sheet.cell(row=k + 2, column=1).value}" + "} %Location\n"
                "\t" + "{" + f"{sheet.cell(row=k + 3, column=1).value}" + "} %Start Date(s)\n"
                "\t" + "{" + f"{sheet.cell(row=k + 4, column=1).value}" + "} %End Date(s)\n"
                "{"
                "	\\begin{cvitems} % Description(s) of tasks/responsibilities\n"
                "\t	\item " + "{" + f"{sheet.cell(row=k + 5, column=1).value}" + "}\n"
                "\t	\item " + "{" + f"{sheet.cell(row=k + 6, column=1).value}" + "}\n"
                "\t	\item " + "{" + f"{sheet.cell(row=k + 7, column=1).value}" + "}\n"
                "}"
        )
        content = content + data
        k = k + 9

    end = (
        "%---------------------------------------------------------\n"
        "\end{cventries}"
    )

    content = content + end

    file = open('resume/experience.tex', 'w')
    file.write(content)
    file.close()