import openpyxl

def readkeycompetencies(filePath, sheetName):
    workbook = openpyxl.load_workbook(filePath)
    sheet = workbook[sheetName]

    content = (
        "% -------------------------------------------------------------------------------\n"
        "%SECTION TITLE\n"
        "% -------------------------------------------------------------------------------\n"
        "\cvsection{Key Competencies}\n"

        "% -------------------------------------------------------------------------------\n"
        "%CONTENT\n"
        "% -------------------------------------------------------------------------------\n"
        "% \\begin{cvskills}\n"

        "% ---------------------------------------------------------\n"
        "% \cvskill\n"
        "\cventry\n"
        "{}\n"
        "{}\n"
        "{}\n"
        "{}\n"
        "{\n"
        "\\begin{cvitems}\n"
    )

    for i in range(1, 4):
        data = "\t\items{"+f"{sheet.cell(row=i, column=1).value}"+"}\n"
        content = content + data

    end = (
        "\end{cvitems}\n"
    "}\n"
    "%---------------------------------------------------------\n"

    "%---------------------------------------------------------\n"
    "% \end{cvskills}\n"
    )

    content = content + end

    file = open('resume/competencies.tex', 'w')
    file.write(content)
    file.close()



