import openpyxl
import os
import shutil
import subprograms.summary as summary
import subprograms.skills as skills
import subprograms.keycompetencies as competencies
import subprograms.workexperience as experience
import subprograms.Education as education

path = './resume'

try:
    os.mkdir(path)
except OSError as error:
    print(error)

imagesource = "./ltts_logo.png"
copyimage = "./lttsLogo.png"

# Copy the content of
# source to destination
dest = shutil.copy(imagesource, copyimage)

shutil.move("./lttsLogo.png", "./resume/lttsLogo.png")

def read(filePath, sheetName):
    workbook = openpyxl.load_workbook(filePath)
    sheet = workbook[sheetName]

    content = ( "%-------------------------------------------------------------------------------\n% CONFIGURATIONS\n%-------------------------------------------------------------------------------\n"
                "\documentclass[11pt, a4paper]{awesome-cv} \n"
               "\geometry{left=1.4cm, top=.8cm, right=1.4cm, bottom=1.8cm, footskip=.5cm}\n"
               "\colorlet{awesome}{awesome-skyblue}\n"
               "\setbool{acvSectionColorHighlight}{true}\n"
               "\\renewcommand{\acvHeaderSocialSep}{\quad\textbar\quad}\n"
                "%-------------------------------------------------------------------------------\n% PROFILE\n%-------------------------------------------------------------------------------\n"
                "\photo[rectangle,edge,right]{./resume/lttsLogo.png}"
                )

    for i in range(1,8):
        data = f"\{sheet.cell(row=i, column=1).value}"+"{"+f"{sheet.cell(row=i, column=2).value}"+"}\n"
        content = content + data

    end =(

        "\n\n\input{resume/summary.tex}\n"
        "\input{resume/skills.tex}\n"
        "\input{resume/competencies.tex}\n"
        "\input{resume/experience.tex}\n"
        "\input{resume/education.tex}\n\n"
        "\end{document}"
    )
    content = content +end

    return content


profile = read("sample1.xlsx", "Profile")
summary.readsummary("sample1.xlsx","Summary")
skills.readskills("sample1.xlsx","Skills")
competencies.readkeycompetencies("sample1.xlsx","Key Competencies")
experience.readwork("sample1.xlsx","Work Experience")
education.readeducation("sample1.xlsx","Education")



file = open('resume.tex','w')
file.write(profile)
file.close()




