import openpyxl
import pandas as pd

class Summary:
    def __init__(self, file, flag):
        self.file = file
        self.flag = flag
        self.generate_summary()

    def generate_summary(self):
        if self.flag == "csv":
            sheet = pd.read_csv(self.file)
            self.value = str(sheet.loc[0, "summary"])
        elif self.flag == "xlsx":
            workbook = openpyxl.load_workbook(self.file)
            sheet = workbook["Summary"]
            self.value = sheet.cell(row=1, column=1).value
