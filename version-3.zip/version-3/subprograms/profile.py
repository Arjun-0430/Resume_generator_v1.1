import openpyxl
import pandas as pd

class Profile:
    def __init__(self, file, flag):
        self.file = file
        self.flag = flag
        self.generate_profile()

    def loadCSV(self):
        sheet = pd.read_csv(self.file)

        self.firstname = str(sheet.loc[0, "First Name"])
        self.lastname = str(sheet.loc[0, "Last Name"])
        self.position = str(sheet.loc[0, "Designation (Job Title)"])
        self.mobile = str(sheet.loc[0, "Mobile No"])
        self.email = str(sheet.loc[0, "Official E-Mail Id"])
        self.dob = str(sheet.loc[0, "DOB:-DD-MM-YY"])
        self.github = str(sheet.loc[0, "Github Profile Link (Optional)"])
        self.linkedin = str(sheet.loc[0, "Linkedin ID (Optional)"])

    def loadExcel(self):
        workbook = openpyxl.load_workbook(self.file)
        sheet = workbook["Profile"]

        name = (sheet.cell(row=1, column=2).value).split(", ")
        self.firstname = name[0]
        self.lastname = name[1]
        self.position = str(sheet.cell(row=2, column=2).value)
        self.mobile = str(sheet.cell(row=3, column=2).value)
        self.email = str(sheet.cell(row=4, column=2).value)
        self.dob = str(sheet.cell(row=5, column=2).value)
        self.github = str(sheet.cell(row=6, column=2).value)
        self.linkedin = str(sheet.cell(row=7, column=2).value)

    def generate_profile(self):
        if self.flag == "csv":
            self.loadCSV()
        elif self.flag == "xlsx":
            self.loadExcel()


