import os,sys
import subprograms.profile as profile
import subprograms.summary as summary
import template.profileTemplate as profileTemplate
import template.summaryTemplate as summaryTemplate

class Master:
    def __init__(self,input_file,flag):
        self.input_file = input_file
        self.flag = flag

    def main(self):
        global base_name
        profile_obj = profile.Profile(self.input_file, self.flag)
        profile_result = profileTemplate.profile_template(profile_obj)

        summary_obj = summary.Summary(self.input_file, self.flag)
        summary_result = summaryTemplate.summary_template(summary_obj)

        if self.flag == "csv":
            x = self.input_file.split("/")
            base_name = x[1]
        elif self.flag == "xlsx":
            base_name = os.path.splitext(os.path.basename(self.input_file))[0]

        output_folder = f"./output/{base_name}"
        os.makedirs(output_folder, exist_ok=True)

        resume_folder = os.path.join(output_folder, 'resume')
        os.makedirs(resume_folder, exist_ok=True)

        with open(output_folder+"/resume.tex","w") as file:
            file.write(profile_result)

        with open(resume_folder+"/summary.tex", "w") as file:
            file.write(summary_result)

if __name__ == "__main__":
    args = sys.argv[1:]
    Master(args[0],args[1]).main()