def summary_template(obj):
    content = (
        """% -------------------------------------------------------------------------------
%SECTION TITLE
% -------------------------------------------------------------------------------
\cvsection{Summary}

% -------------------------------------------------------------------------------
%CONTENT
% -------------------------------------------------------------------------------
\\begin{cvparagraph}

% ---------------------------------------------------------\n"""
    )

    if (obj.value) != "None" or (obj.value) != "nan":
        data = f"{obj.value}\n"
    else:
        data = f"%no summary\n"
    content = content + data

    end = "\end{cvparagraph}"

    content = content + end
    return content