def profile_template(obj):
 content = ("""
%!TEX TS-program = xelatex
%!TEX encoding = UTF-8 Unicode
% Awesome CV LaTeX Template for CV/Resume
%
% This template has been downloaded from:
% https://github.com/posquit0/Awesome-CV
%
% Author:
% Claud D. Park <posquit0.bj@gmail.com>
% http://www.posquit0.com
%
% Template license:
% CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/)
%


%-------------------------------------------------------------------------------
% CONFIGURATIONS
%-------------------------------------------------------------------------------
% A4 paper size by default, use 'letterpaper' for US letter
\documentclass[11pt, a4paper]{awesome-cv}

% Configure page margins with geometry
\geometry{left=1.4cm, top=.8cm, right=1.4cm, bottom=1.8cm, footskip=.5cm}

% Color for highlights
% Awesome Colors: awesome-emerald, awesome-skyblue, awesome-red, awesome-pink, awesome-orange
%                 awesome-nephritis, awesome-concrete, awesome-darknight
%\colorlet{awesome}{awesome-red}
\colorlet{awesome}{awesome-skyblue}
% Uncomment if you would like to specify your own color
% \definecolor{awesome}{HTML}{CA63A8}

% Colors for text
% Uncomment if you would like to specify your own color
% \definecolor{darktext}{HTML}{414141}
% \definecolor{text}{HTML}{333333}
% \definecolor{graytext}{HTML}{5D5D5D}
% \definecolor{lighttext}{HTML}{999999}
% \definecolor{sectiondivider}{HTML}{5D5D5D}

% Set false if you don't want to highlight section with awesome color
\setbool{acvSectionColorHighlight}{true}

% If you would like to change the social information separator from a pipe (|) to something else
\\renewcommand{\\acvHeaderSocialSep}{\quad\\textbar\quad}


%-------------------------------------------------------------------------------
%	PERSONAL INFORMATION
%	Comment any of the lines below if they are not required
%-------------------------------------------------------------------------------
% Available options: circle|rectangle,edge/noedge,left/right\n

                           """
            "\n\photo[rectangle,edge,right]{./lttsLogo.png}\n"
            )
 data = ""

 if (obj.firstname == "None" or obj.firstname == "nan"):
     data = data + "%\\name{" + f"{obj.firstname}" + "}{" + f"{obj.lastname}" + "}\n"
 elif (obj.lastname == "None" or obj.lastname == "nan"):
     data = data + "%\\name{" + f"{obj.firstname}" + "}\n"
 else:
     data = data + "\\name{" + f"{obj.firstname}" + "}{" + f"{obj.lastname}" + "}\n"

 if (obj.position == "None" or obj.position == "nan"):
     data = data + "%\position{" + f"{obj.position}" + "{\enskip\cdotp\enskip}Highlight}\n"
 else:
     data = data + "\position{" + f"{obj.position}" + "{\enskip\cdotp\enskip}Highlight}\n"

 if (obj.mobile == "None" or obj.mobile == "nan"):
     data = data + "%\mobile{" + f"{obj.mobile}" + "}\n"
 else:
     data = data + "\mobile{" + f"{obj.mobile}" + "}\n"

 if (obj.email == "None" or obj.email == "nan"):
     data = data + "%\email{" + f"{obj.email}" + "}\n"
 else:
     data = data + "\email{" + f"{obj.email}" + "}\n"


 if (obj.dob == "None" or obj.dob == "nan"):
     data = data + "%\dateofbirth{" + f"{obj.dob}" + "}\n"
 else:
     data = data + "\dateofbirth{" + f"{obj.dob}" + "}\n"


 if (obj.github == "None" or obj.github == "nan"):
     data = data + "%\github{" + f"{obj.github}" + "}\n"
 else:
     data = data + "\github{" + f"{obj.github}" + "}\n"

 if (obj.linkedin == "None" or obj.linkedin == "nan"):
     data = data + "%\linkedin{" + f"{obj.linkedin}" + "}\n"
 else:
     data = data + "\linkedin{" + f"{obj.linkedin}" + "}\n"

 content = content + data

 end = """\n\n
\quote{``Beautiful Quote you would like"}


%-------------------------------------------------------------------------------
\\begin{document}

% Print the header with above personal information
% Give optional argument to change alignment(C: center, L: left, R: right)
\makecvheader[C]

% Print the footer with 3 arguments(<left>, <center>, <right>)
% Leave any of these blank if they are not needed
\makecvfooter
  {\\today}
  {Username~~~·~~~Résumé}
  {\\thepage}


%-------------------------------------------------------------------------------
%	CV/RESUME CONTENT
%	Each section is imported separately, open each file in turn to modify content
%-------------------------------------------------------------------------------
\input{resume/summary.tex}
\input{resume/skills.tex}
\input{resume/competencies.tex}
\input{resume/experience.tex}
\input{resume/education.tex}
\input{resume/trainings.tex}
\input{resume/opensource.tex}

%-------------------------------------------------------------------------------
\end{document}
            """
 content = content + end
 return content